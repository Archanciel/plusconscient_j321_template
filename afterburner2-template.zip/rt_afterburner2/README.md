plusconscient_j321_template
===========================

Template customized for Joomla 3.2.1 and later. This template version is rhe continuation of the template customizations performed on plusconscient_j3_template.
